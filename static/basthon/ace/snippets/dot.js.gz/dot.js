ace.define("ace/snippets/dot",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="dot"});                (function() {
                    ace.require(["ace/snippets/dot"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            