ace.define("ace/snippets/haskell_cabal",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="haskell_cabal"});                (function() {
                    ace.require(["ace/snippets/haskell_cabal"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            