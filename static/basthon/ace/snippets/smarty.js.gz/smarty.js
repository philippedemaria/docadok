ace.define("ace/snippets/smarty",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="smarty"});                (function() {
                    ace.require(["ace/snippets/smarty"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            