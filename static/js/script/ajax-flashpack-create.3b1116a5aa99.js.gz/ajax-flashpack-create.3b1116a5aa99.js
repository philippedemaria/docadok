define(['jquery', 'bootstrap', 'ui', 'ui_sortable'], function ($) {
    $(document).ready(function () {
        console.log("chargement JS ajax-flashpack.js OK");

  
        $('#id_themes_div').hide();

        $('#id_is_publish').prop('checked', true);
        $('#id_is_archive').prop('checked', false); 
        $('#id_is_creative').prop('checked', false); 
        
});

});

