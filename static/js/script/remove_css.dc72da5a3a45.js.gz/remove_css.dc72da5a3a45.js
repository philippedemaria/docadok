define(['jquery', 'bootstrap'], function ($) {
    $(document).ready(function () {
	{


		console.log("---- NEW test remove_css.js ---") ;	


  $("#this_course_viewer").find(".projection").attr("style","");
  $("#this_course_viewer").find(".projection").removeClass("projection");
 


    };
  
});
    
});
 