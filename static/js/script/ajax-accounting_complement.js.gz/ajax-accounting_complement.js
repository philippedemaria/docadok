define(['jquery', 'bootstrap' ], function ($) {
    $(document).ready(function () {
        console.log("chargement JS ajax-accoutning_complement.js OK");


        $('#id_is_abonnement').prop('checked', false);
        $('#id_is_gar').prop('checked', false);
        $('#id_is_payal').prop('checked', false);

     
 


    });

});
 

 
 

 
 
 