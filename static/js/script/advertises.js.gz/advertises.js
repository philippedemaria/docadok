define(['jquery','bootstrap' ], function ($) {
    $(document).ready(function () {
        console.log("chargement JS inside_data_tab.js OK");

     $("#nouveaute").show(500);

    });
});