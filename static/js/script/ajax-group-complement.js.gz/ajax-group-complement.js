define(['jquery', 'bootstrap'], function ($) {
    $(document).ready(function () {
        console.log("chargement JS ajax-course-complement.js OK");


            $('[type=checkbox]').prop('checked', false);            


});

});

