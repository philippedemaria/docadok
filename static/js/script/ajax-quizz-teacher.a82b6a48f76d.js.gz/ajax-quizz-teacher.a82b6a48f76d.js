define(['jquery',  'bootstrap', ], function ($) {
    $(document).ready(function () {
 
        console.log(" ajax-quizz-teacher chargé "); 

        

        setTimeout("location.reload(true);", 2000);


 





    });
});