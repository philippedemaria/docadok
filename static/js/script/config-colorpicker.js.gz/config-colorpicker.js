
// todo: arreter de le charger avec common et mettre des require sur les pages concernées
define(['jquery', 'colorpicker'], function ($) {
    $('#color-picker-component').colorpicker();
});