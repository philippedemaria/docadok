define(['jquery', 'ui'], function ($) {
    $(function () {
        $("#draggable").draggable();
    });
});
